import { Injectable } from '@angular/core';

@Injectable()
export class RouterService {

  routeToDashboard() {

  }

  routeToLogin() {

  }

  routeToEditNoteView(noteId) {

  }

  routeBack() {

  }

  routeToNoteView() {

  }

  routeToListView() {
    
  }
}
