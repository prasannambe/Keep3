import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Note } from '../note';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class NotesService {

  notes: Array<Note>;
  notesSubject: BehaviorSubject<Array<Note>>;
  constructor(private httpClient: HttpClient, private authService: AuthenticationService) { }

  fetchNotesFromServer() {

  }

  getNotes(): BehaviorSubject<Array<Note>> {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`);

    return this.httpClient.get<Array<Note>>('http://localhost:3000/api/v1/notes', {
      headers : headers
    });
  }

  addNote(note: Note): Observable<Note> {
    const headers = new HttpHeaders().set('Authorization', `Bearer ${this.authService.getBearerToken()}`);

    return this.httpClient.post<Note>('http://localhost:3000/api/v1/notes', note, {
      headers : headers
    });
  }

  editNote(note: Note): Observable<Note> {

  }

  getNoteById(noteId): Note {

  }
}
